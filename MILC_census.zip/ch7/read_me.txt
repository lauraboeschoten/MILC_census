The data is downloaded from Censushub and can be found in 'xlsoutput_HC50_2017_07_11_13_59.xlsx'. This dataset is loaded into '1_TOP_prepare_data.R' and the first preparations on the data are made. 

Second, the simulation study is run using the code in '2_TOP_simulate.R'. This top level code calls the functions located in the folders 'functions_simulate' to run the simulation and 'functions_results' to obtain the relevant results from the simulation study. 

Third, the simulation output can be obtained using the top level function '3_TOP_evaluate.R'. This function calls the lower level functions found in the folder 'functions_evaluate'. 