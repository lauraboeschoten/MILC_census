template_LC_A <- function(envir, j, b, temp.filename.base) {
  
  temp.filename <- paste(temp.filename.base, ".lgs", sep="")                        
  template      <- file("syntax_A.brew", 'r')
  brew(template, output=temp.filename) 
  close(template)
  #shell(sprintf('"C:\\Users\\lboescho\\LatentGOLD5.1\\lg51.exe" %s /b /l', temp.filename))
  #shell(sprintf('"C:\\Users\\t.brakenhoff\\Documents\\LatentGOLD5.1\\lg51.exe" %s /b /l', temp.filename))
  shell(sprintf('"C:\\Users\\TSB-MTO\\Desktop\\LatentGOLD5.1\\lg51.exe" %s /b /l', temp.filename))

  }



