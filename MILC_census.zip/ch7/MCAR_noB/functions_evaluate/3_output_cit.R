
setwd("C:/Users/lboescho/surfdrive/project_census/simulatie/MCAR_noB")

options(scipen = 999)

library(xtable)
library(plyr)

#global parameters
nsim     <- 500

ordata <- read.table("original_data.txt", header=TRUE)
ordata$ext <- rep(1, nrow(ordata))

#-------------------------------------------------------------------------------

pop <- as.numeric(as.character(unlist(ddply(ordata, .(citizen), summarise, freq=sum(as.numeric(as.character(ext)))))[5:8]))
  
res <- matrix(NA, nsim, 8)
  
for(i in 1:nsim){
  res[i,] <- as.matrix(read.delim(paste0("store_res/3_impcit_5/impcit_",i,".txt"), header=T, sep="")) 
}
  
bias <-  matrix(NA, nsim, (length(pop)))
cov <- matrix(NA, nsim, (length(pop)*3))
  
for(i in 1:(length(pop))){
  bias[,i]   <- res[,i]-pop[i]
}
  
a <- round(colMeans(bias))                                               # absolute bias

for(i in 1:(length(pop))){
  cov[,i]    <- exp(log(res[,i])-1.96*sqrt(res[,i+(length(pop))]))
  cov[,i+(length(pop))]  <- exp(log(res[,i])+1.96*sqrt(res[,i+(length(pop))]))
  cov[,i+(length(pop)*2)]  <- pop[i] > cov[,i] & pop[i] < cov[,i+(length(pop))]
}
  
b <- colSums(cov[,c((length(pop)*2+1):(length(pop)*3))])/nsim*100               # uncorrected coverage
c <- round(colMeans(cov[,c((length(pop)+1):(length(pop)*2))]-cov[,c(1:(length(pop)))]),4) # CI width
e <- f <- d <- NULL
  
for(i in 1:(length(pop))){
  e[i] <- sqrt(mean(res[,i+(length(pop))]))/sd(log(res[,i]))                    # sesd
  f[i] <- sqrt(mean(bias[,i]^2))                                            # rmse
}
  

#-------------------------------------------------------------------------------

pop <- as.numeric(as.character(unlist(ddply(ordata, .(citizen), summarise, freq=sum(as.numeric(as.character(ext)))))[5:8]))
  
res <- matrix(NA, nsim, 8)
  
for(i in 1:nsim){
  res[i,] <- as.matrix(read.delim(paste0("store_res/3_impcit_10/impcit_",i,".txt"), header=T, sep="")) 
}
  
bias <-  matrix(NA, nsim, (length(pop)))
cov <- matrix(NA, nsim, (length(pop)*3))
  
for(i in 1:(length(pop))){
  bias[,i]   <- res[,i]-pop[i]
}
  
a <- round(colMeans(bias))                                               # absolute bias
  
for(i in 1:(length(pop))){
  cov[,i]    <- exp(log(res[,i])-1.96*sqrt(res[,i+(length(pop))]))
  cov[,i+(length(pop))]  <- exp(log(res[,i])+1.96*sqrt(res[,i+(length(pop))]))
  cov[,i+(length(pop)*2)]  <- pop[i] > cov[,i] & pop[i] < cov[,i+(length(pop))]
}
  
b <- colSums(cov[,c((length(pop)*2+1):(length(pop)*3))])/nsim*100               # uncorrected coverage
c <- round(colMeans(cov[,c((length(pop)+1):(length(pop)*2))]-cov[,c(1:(length(pop)))]),4) # CI width
e <- f <- d <- NULL
  
for(i in 1:(length(pop))){
  e[i] <- sqrt(mean(res[,i+(length(pop))]))/sd(log(res[,i]))                    # sesd
  f[i] <- sqrt(mean(bias[,i]^2))                                             # rmse
}

# ------------------------------------------------------------------------------

pop <- as.numeric(as.character(unlist(ddply(ordata, .(citizen), summarise, freq=sum(as.numeric(as.character(ext)))))[5:8]))
  
res <- matrix(NA, nsim, 8)

for(i in 1:nsim){
  res[i,] <- as.matrix(read.delim(paste0("store_res/3_impcit_20/impcit_",i,".txt"), header=T, sep="")) 
}
  
bias <-  matrix(NA, nsim, (length(pop)))
cov <- matrix(NA, nsim, (length(pop)*3))
  
for(i in 1:(length(pop))){
  bias[,i]   <- res[,i]-pop[i]
}
  
a <- round(colMeans(bias))                                               # absolute bias
  
for(i in 1:(length(pop))){
  cov[,i]    <- exp(log(res[,i])-1.96*sqrt(res[,i+(length(pop))]))
  cov[,i+(length(pop))]  <- exp(log(res[,i])+1.96*sqrt(res[,i+(length(pop))]))
  cov[,i+(length(pop)*2)]  <- pop[i] > cov[,i] & pop[i] < cov[,i+(length(pop))]
}
  
b <- colSums(cov[,c((length(pop)*2+1):(length(pop)*3))])/nsim*100               # uncorrected coverage
c <- round(colMeans(cov[,c((length(pop)+1):(length(pop)*2))]-cov[,c(1:(length(pop)))]),4) # CI width
e <- f <- d <- NULL
  
for(i in 1:(length(pop))){
  e[i] <- sqrt(mean(res[,i+(length(pop))]))/sd(log(res[,i]))                    # sesd
  f[i] <- sqrt(mean(bias[,i]^2))                                             # rmse
}
  
