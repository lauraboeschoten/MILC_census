
setwd("C:/Users/lboescho/surfdrive/project_census/simulatie/MCAR_noB")

options(scipen = 999)

library(xtable)
library(plyr)

#global parameters
nsim     <- 500

source("functions_evaluate/1_output_gen.R")
source("functions_evaluate/2_output_par.R")
source("functions_evaluate/3_output_cit.R")
source("functions_evaluate/4_output_AP.R")
source("functions_evaluate/5_output_ALL.R")
source("functions_evaluate/6_output_imp.R")

ordata <- read.table("original_data.txt", header=TRUE)
ordata$ext <- rep(1, nrow(ordata))


# ------------------------------------------------------------------------------
# 1. res gen
out_gen_5  <- output_gen_5(ordata)
out_gen_10 <- output_gen_10(ordata)
out_gen_15 <- output_gen_15(ordata)
out_gen_20 <- output_gen_20(ordata)

# ------------------------------------------------------------------------------
# 2. res par
out_par_5  <- output_par_5(ordata)
out_par_10 <- output_par_10(ordata)
out_par_15 <- output_par_15(ordata)
out_par_20 <- output_par_20(ordata)

# ------------------------------------------------------------------------------
# 3. res cit
out_cit_5  <- output_cit_5(ordata)
out_cit_10 <- output_cit_10(ordata)
out_cit_15 <- output_cit_15(ordata)
out_cit_20 <- output_cit_20(ordata)

# ------------------------------------------------------------------------------
# 4. res AP
out_AP_5  <- output_AP_5(ordata)
out_AP_10 <- output_AP_10(ordata)
out_AP_15 <- output_AP_15(ordata)
out_AP_20 <- output_AP_20(ordata)

# ------------------------------------------------------------------------------
# 5. res ALL
out_ALL_5  <- output_ALL_5(ordata)
out_ALL_10 <- output_ALL_10(ordata)
out_ALL_15 <- output_ALL_15(ordata)
out_ALL_20 <- output_ALL_20(ordata)

bb <- as.data.frame(cbind(pop, a))

# ------------------------------------------------------------------------------
# 6. res imp

out_imp_5  <- output_imp_5(ordata)
out_imp_10 <- output_imp_10(ordata)
out_imp_15 <- output_imp_15(ordata)
out_imp_20 <- output_imp_20(ordata)

