setwd("C:/Users/lboescho/surfdrive/project_census/simulatie/Y1")

library(plyr)
library(brew)
library(Hmisc)
library(tidyr)
library(MASS)

source("functions_simulate/1_create_data.R")

source("functions_results/1_res_gen.R")
source("functions_results/2_res_par.R")
source("functions_results/3_res_cit.R")
source("functions_results/4_res_AP.R")
source("functions_results/5_res_ALL.R")
source("functions_results/6_res_imp.R")


probs <- rep(0.5, 21)
nsim <- 500


exdata <- read.table("C:/Users/lboescho/surfdrive/project_census/simulatie/Y1/original_data.txt", header=TRUE)

#

for( j in 1:nsim){
  cat(j)
  set.seed(j)
  begin <- Sys.time()
  longiedata <- create_data(exdata, probs, nboot)
  
  
  res_gen(longiedata, j)
  res_par(longiedata, j)
  res_cit(longiedata, j)
  res_AP(longiedata, j)
  res_ALL(longiedata, j)
  res_imp(longiedata, j)
  
  end <- Sys.time()
  print(end-begin)
}
