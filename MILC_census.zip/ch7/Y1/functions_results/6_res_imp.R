res_imp <- function(longiedata, j){
  
  impimp     <- as.numeric(as.character(unlist(ddply(longiedata, .(gend_in1, part_in1, citi_in1), summarise, freq=sum(as.numeric(as.character(freq))), .drop=FALSE))[97:128]))

  write.table(impimp, paste0("store_res/6_impimp/impimp_",j,".txt"), row.names = F, quote = F)
    
  
}