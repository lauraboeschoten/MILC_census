res_cit <- function(longiedata, j){
  
  impcit     <- as.numeric(as.character(unlist(ddply(longiedata, .(citi_in1), summarise, freq=sum(as.numeric(as.character(freq)))))[5:8]))

  write.table(impcit, paste0("store_res/3_impcit/impcit_",j,".txt"), row.names = F, quote = F)
  
}