res_gen <- function(longiedata, j){
  
  impgen  <- as.numeric(as.character(unlist(ddply(longiedata, .(gend_in1), summarise, freq=sum(as.numeric(as.character(freq)))))[3:4]))
  
  write.table(impgen, paste0("store_res/1_impgen/impgen_",j,".txt"), row.names = F, quote = F)
        
}