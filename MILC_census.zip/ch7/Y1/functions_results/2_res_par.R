res_par <- function(longiedata, j){
  
    imppar  <- as.numeric(as.character(unlist(ddply(longiedata, .(part_in1), summarise, freq=sum(as.numeric(as.character(freq)))))[5:8]))
  
    write.table(imppar, paste0("store_res/2_imppar/imppar_",j,".txt"), row.names = F, quote = F)
    
  
}