res_ALL <- function(longiedata, j){
  
  impALL    <- as.numeric(as.character(unlist(ddply(longiedata, .(gend_in1, part_in1, citi_in1, age, marstat, birth), summarise, freq=sum(as.numeric(as.character(freq))), .drop=FALSE))[84673:98784]))

  write.table(impALL, paste0("store_res/5_impALL/impALL_",j,".txt"), row.names = F, quote = F)
    
}