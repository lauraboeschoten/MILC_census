res_AP <- function(longiedata, j){
  
  impAP   <- as.numeric(as.character(unlist(ddply(longiedata, .(part_in1, age), summarise, freq=sum(as.numeric(as.character(freq))), .drop=FALSE))[169:252]))
    
  write.table(impAP, paste0("store_res/4_impAP/impAP_",j,".txt"), row.names = F, quote = F)
    

}