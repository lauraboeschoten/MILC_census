
create_data <- function(exdata, probs, nboot){
  
    ordata <- exdata 
    
    # ME in GENDER
    
    ordata$gend_in1 <- ifelse(rbinom(nrow(ordata),1,0.95),ordata$gender,                # gender 1 1% ME
                              factor(ordata$gender, levels=rev(levels(ordata$gender))))
       
    # ME in partners
    
    ordata$part_in1 <- ifelse(rbinom(nrow(ordata),1,0.95),ordata$partners,0)             # partner 1 1% ME
     
    part11 <- subset(ordata, ordata[,"part_in1"]==0)
    part12 <- subset(ordata, ordata[,"part_in1"]!=0)
    
    probbies <- unlist(table(ordata$partners)/sum(table(ordata$partners)))
    
    part11$part_in1[part11$partners=="Loneparents"]   <- sample(c(2,3,4),length(part11$part_in1[part11$partners=="Loneparents"]),replace=T,prob=probbies[c(2,3,4)])
    part11$part_in1[part11$partners=="Notapplicable"] <- sample(c(1,3,4),length(part11$part_in1[part11$partners=="Notapplicable"]),replace=T,prob=probbies[c(1,3,4)])
    part11$part_in1[part11$partners=="Partners"]      <- sample(c(1,2,4),length(part11$part_in1[part11$partners=="Partners"]),replace=T,prob=probbies[c(1,2,4)])
    part11$part_in1[part11$partners=="Sonsdaughters"] <- sample(c(1,2,3),length(part11$part_in1[part11$partners=="Sonsdaughters"]),replace=T,prob=probbies[c(1,2,3)])
    
  #
    ordata2 <- rbind(part11,part12)
    
    ordata  <- ordata2
    
    # ME in citizen
    
    ordata$citi_in1 <- ifelse(rbinom(nrow(ordata),1,0.95),ordata$citizen,0)             # partner 1 1% ME
     
    part11 <- subset(ordata, ordata[,"citi_in1"]==0)
    part12 <- subset(ordata, ordata[,"citi_in1"]!=0)
    
    probbies <- unlist(table(ordata$citizen)/sum(table(ordata$citizen)))
    
    part11$citi_in1[part11$citizen=="CitizenEU"]    <- sample(c(2,3,4),length(part11$part_in1[part11$citizen=="CitizenEU"]),replace=T,prob=probbies[c(2,3,4)])
    part11$citi_in1[part11$citizen=="CitizenNL"]    <- sample(c(1,3,4),length(part11$part_in1[part11$citizen=="CitizenNL"]),replace=T,prob=probbies[c(1,3,4)])
    part11$citi_in1[part11$citizen=="CitizennotEU"] <- sample(c(1,2,4),length(part11$part_in1[part11$citizen=="CitizennotEU"]),replace=T,prob=probbies[c(1,2,4)])
    part11$citi_in1[part11$citizen=="Notstated"]    <- sample(c(1,2,3),length(part11$part_in1[part11$citizen=="Notstated"]),replace=T,prob=probbies[c(1,2,3)])
    
    ordata2 <- rbind(part11,part12)
    ordata  <- ordata2
    
    ordata$extra <- rep(1, nrow(ordata))
    
    longiedata <- ddply(ordata, .(age,marstat,gender,birth,partners,citizen,gend_in1,
                                    part_in1,citi_in1), summarise, freq=sum(extra))
    
    #write.table(longiedata, "longdata.txt", row.names = F, quote = F)
    return(longiedata)
}