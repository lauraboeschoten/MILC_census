setwd("C:/Users/lboescho/surfdrive/project_census/simulatie/Y1")

options(scipen = 999)

library(xtable)
library(plyr)

#global parameters
nsim     <- 500

ordata <- read.table("C:/Users/lboescho/surfdrive/project_census/simulatie/Y1/original_data.txt", header=TRUE)
ordata$ext <- rep(1, nrow(ordata))

# ------------------------------------------------------------------------------



pop <- as.numeric(as.character(unlist(ddply(ordata, .(gender), summarise, freq=sum(as.numeric(as.character(ext)))))[3:4]))
  
res <- matrix(NA, nsim, 4)
  
for(i in 1:nsim){
  res[i,] <- as.matrix(read.delim(paste0("store_res/1_impgen/impgen_",i,".txt"), header=T, sep="")) 
}
  
bias <-  matrix(NA, nsim, (length(pop)))
cov <- matrix(NA, nsim, (length(pop)*3))

for(i in 1:(length(pop))){
  bias[,i]   <- res[,i]-pop[i]
}
  
a <- round(colMeans(bias))                                               # absolute bias
  
f <- d <- NULL
  
for(i in 1:(length(pop))){                   # sesd
  f[i] <- sqrt(mean(bias[,i]^2))                                             # rmse
}
