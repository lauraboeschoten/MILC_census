setwd("C:/Users/lboescho/surfdrive/project_census/simulatie/Y1")

options(scipen = 999)

library(xtable)
library(plyr)

#global parameters
nsim     <- 500

ordata <- read.table("C:/Users/lboescho/surfdrive/project_census/simulatie/Y1/original_data.txt", header=TRUE)
ordata$ext <- rep(1, nrow(ordata))

# ------------------------------------------------------------------------------

pop <- as.numeric(as.character(unlist(ddply(ordata, .(citizen), summarise, freq=sum(as.numeric(as.character(ext)))))[5:8]))
  
res <- matrix(NA, nsim, 8)
  
for(i in 1:nsim){
  res[i,] <- as.matrix(read.delim(paste0("store_res/3_impcit/impcit_",i,".txt"), header=T, sep="")) 
}
  
bias <-  matrix(NA, nsim, (length(pop)))
  
for(i in 1:(length(pop))){
  bias[,i]   <- res[,i]-pop[i]
}
  
a <- round(colMeans(bias))                                               # absolute bias
  
f <- d <- NULL
  
for(i in 1:(length(pop))){
  f[i] <- sqrt(mean(bias[,i]^2))                                            # rmse
}
  
