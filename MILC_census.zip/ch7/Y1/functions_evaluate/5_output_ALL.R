output_ALL <- function(ordata){
  
  pop <- as.numeric(as.character(unlist(ddply(ordata, .(gender, partners, citizen, age, marstat, birth), summarise, freq=sum(as.numeric(as.character(ext))), .drop=FALSE))[84673:98784]))
  
  res <- matrix(NA, nsim, 28224)
  
  for(i in 1:nsim){
    res[i,] <- as.matrix(read.delim(paste0("store_res/5_impALL/impALL_",i,".txt"), header=T, sep="")) 
  }
  
  bias <-  matrix(NA, nsim, (length(pop)))
 
  for(i in 1:(length(pop))){
    bias[,i]   <- res[,i]-pop[i]
  }
  
  a <- round(colMeans(abs(bias)),4)                                               # absolute bias
  
  f <- d <- NULL
  
  for(i in 1:(length(pop))){
    f[i] <- sqrt(abs(mean(bias[,i])))                                             # rmse
  }
  
  for(i in 1:(length(pop))){d <- c(d,a[i],f[i])}
  
  d <- matrix(t(as.matrix(d)),byrow=T, ncol=2)
  colnames(d) <- c("bias","rmse")
  zz <- ddply(ordata, .(gender, partners, citizen, age, marstat, birth), summarise, freq=sum(as.numeric(as.character(ext))), .drop=FALSE)
  
  dz <- cbind(zz, d)
  xt <- xtable(dz, digits=4)
  
  plot(table(b))
  plot(table(g))
  plot(dz$freq, dz$a)
  
  return(xt)
}
