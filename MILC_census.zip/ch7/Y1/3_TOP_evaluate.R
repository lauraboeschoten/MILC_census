setwd("C:/Users/lboescho/surfdrive/project_census/simulatie/Y1")

options(scipen = 999)

library(xtable)
library(plyr)

#global parameters
nsim     <- 500

source("functions_evaluate/1_output_gen.R")
source("functions_evaluate/2_output_par.R")
source("functions_evaluate/3_output_cit.R")
source("functions_evaluate/4_output_AP.R")
source("functions_evaluate/5_output_ALL.R")
source("functions_evaluate/6_output_imp.R")

ordata <- read.table("C:/Users/lboescho/surfdrive/project_census/simulatie/Y1/original_data.txt", header=TRUE)
ordata$ext <- rep(1, nrow(ordata))


# ------------------------------------------------------------------------------
out_gen  <- output_gen(ordata)
out_par  <- output_par(ordata)
out_cit  <- output_cit(ordata)
out_AP <- output_AP(ordata)
out_ALL  <- output_ALL(ordata)

bb <- as.data.frame(cbind(pop, a))
out_imp  <- output_imp(ordata)
