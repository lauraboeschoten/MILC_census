LC_models <- function(nboot, j){
  
  imps <- vector("list", nboot) # for every bootstrap sample
  
  for(b in 1:nboot){
    #begin <- Sys.time()
    envir       <- new.env()  #LC model A on bootstrap sample excludeall
    template_LC_A(
      envir              = envir,
      j                  = j,
      b                  = b,
      temp.filename.base = paste0("model")
    )
    
    envir       <- new.env() # parameters of LC model A are used to estimate LC 
    template_LC_B(           # model B includeall on original dataset
      envir              = envir,
      j                  = j,
      b                  = b,
      temp.filename.base = paste0("model")
    )
    
    post <- read.delim(paste0("posteriors",b,".dat"), header=T, sep="\t") # laat een set posteriors in 
    post <- as.data.frame(post)
    cols <- c(28:59) 
    post[,cols] <- apply(post[,cols], 2, function(x) as.numeric(as.character(x)))
    post[,c(60:91)] <-NA
    colnames(post)[c(60:91)] <- substring(colnames(post)[c(28:59)],5,9)
    
    postext <- post
    postext[,c(60:91)] <- t(apply(postext, 1, function(x) rmultinom(1, x["freq"], x[c(28:59)]))) # trek imputaties
      
    post_long <- gather(postext, joints, frequency, 60:91, factor_key = TRUE)
    post_long_2 <- post_long[post_long$frequency != 0,]
      
    imppost <- as.data.frame(post_long_2)[,c(1:9,11:13,60:61)]
      
    colnames(imppost)[14] <- "freq"
    imppost[,c("i_gen","i_part","i_cit")] <- matrix(unlist(strsplit(as.character(imppost[,"joints"]),"_")), nrow(imppost), 3, byrow=T)
      
    imps[[b]] <- imppost
    #end <- Sys.time()
    #print(end-begin)
    }
  
  return(imps)
}


