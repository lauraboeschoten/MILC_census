load("imps.Rdata")

library(plyr)

impgen_resQb  <- matrix(NA, 2,     nboot)
impgen_resSE  <- matrix(NA, 2,     nboot)
imppar_resQb  <- matrix(NA, 4,     nboot)
imppar_resSE  <- matrix(NA, 4,     nboot)
impcit_resQb  <- matrix(NA, 4,     nboot)
impcit_resSE  <- matrix(NA, 4,     nboot)
impAP_resQb   <- matrix(NA, 84,    nboot)
impAP_resSE   <- matrix(NA, 84,    nboot)
impALL_resQb  <- matrix(NA, 14112, nboot)
impALL_resSE  <- matrix(NA, 14112, nboot)

for(i in 1:nboot){
  cat(i)
  impgen_resQb[,i]  <-      as.numeric(as.character(unlist(ddply(imps[[i]], .(i_gen), summarise, freq=sum(as.numeric(freq))))[3:4]))/
                        sum(as.numeric(as.character(unlist(ddply(imps[[i]], .(i_gen), summarise, freq=sum(as.numeric(freq))))[3:4])))
  impgen_resSE[,i]  <-  impgen_resQb[,i]*(1-impgen_resQb[,i])/
                        sum(as.numeric(as.character(unlist(ddply(imps[[i]], .(i_gen), summarise, freq=sum(as.numeric(freq))))[3:4])))
    
  imppar_resQb[,i]  <-      as.numeric(as.character(unlist(ddply(imps[[i]], .(i_part), summarise, freq=sum(as.numeric(freq))))[5:8]))/
                        sum(as.numeric(as.character(unlist(ddply(imps[[i]], .(i_part), summarise, freq=sum(as.numeric(freq))))[5:8])))
  imppar_resSE[,i]  <-  imppar_resQb[,i]*(1-imppar_resQb[,i])/
                        sum(as.numeric(as.character(unlist(ddply(imps[[i]], .(i_part), summarise, freq=sum(as.numeric(freq))))[5:8])))
  
  impcit_resQb[,i]  <-      as.numeric(as.character(unlist(ddply(imps[[i]], .(i_cit), summarise, freq=sum(as.numeric(freq))))[5:8]))/
                        sum(as.numeric(as.character(unlist(ddply(imps[[i]], .(i_cit), summarise, freq=sum(as.numeric(freq))))[5:8])))
  impcit_resSE[,i]  <-  impcit_resQb[,i]*(1-impcit_resQb[,i])/
                        sum(as.numeric(as.character(unlist(ddply(imps[[i]], .(i_cit), summarise, freq=sum(as.numeric(freq))))[5:8])))
  
  impAP_resQb[,i]   <-      as.numeric(as.character(unlist(ddply(imps[[i]], .(i_part, age), summarise, freq=sum(as.numeric(freq)), .drop=FALSE))[169:252]))/
                        sum(as.numeric(as.character(unlist(ddply(imps[[i]], .(i_part, age), summarise, freq=sum(as.numeric(freq)), .drop=FALSE))[169:252])))
  impAP_resSE[,i]   <-  impAP_resQb[,i]*(1-impAP_resQb[,i])/
                        sum(as.numeric(as.character(unlist(ddply(imps[[i]], .(i_part, age), summarise, freq=sum(as.numeric(freq)), .drop=FALSE))[169:252])))
  
  impALL_resQb[,i]  <-      as.numeric(as.character(unlist(ddply(imps[[i]], .(i_gen, i_part, i_cit, age, marstat, birth), summarise, freq=sum(as.numeric(freq)), .drop=FALSE))[84673:98784]))/
                        sum(as.numeric(as.character(unlist(ddply(imps[[i]], .(i_gen, i_part, i_cit, age, marstat, birth), summarise, freq=sum(as.numeric(freq)), .drop=FALSE))[84673:98784])))
  impALL_resSE[,i]  <-  impALL_resQb[,i]*(1-impALL_resQb[,i])/
                        sum(as.numeric(as.character(unlist(ddply(imps[[i]], .(i_gen, i_part, i_cit, age, marstat, birth), summarise, freq=sum(as.numeric(freq)), .drop=FALSE))[84673:98784])))

}

impgen <- matrix(NA, 1, 4)
Ubar <- Between <- matrix(NA, 1, 2)

for(i in 1:2){
  impgen[1,i]   <- mean(impgen_resQb[i,])
  Ubar[,i]         <- mean(impgen_resSE[i,])
  Between[,i]      <- var(impgen_resQb[i,])
  impgen[1,i+2] <- Ubar[,i] + (nboot+1) * (Between[,i]/nboot)
}


