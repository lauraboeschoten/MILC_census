create_data <- function(exdata, probs, nboot){
  
    ordata <- exdata 
  
    
    # ME in GENDER
    
    ordata$gend_in2 <- ifelse(rbinom(nrow(ordata),1,0.95),ordata$gender,                # gender 2 5% ME
                              factor(ordata$gender, levels=rev(levels(ordata$gender))))
    
    # ME in partners
    
    ordata$part_in2 <- ifelse(rbinom(nrow(ordata),1,0.95),ordata$partners,0)             # partner 2 5% ME
    
    probbies <- unlist(table(ordata$partners)/sum(table(ordata$partners)))

    part21 <- subset(ordata, ordata[,"part_in2"]==0)
    part22 <- subset(ordata, ordata[,"part_in2"]!=0)
    
    part21$part_in2[part21$partners=="Loneparents"]   <- sample(c(2,3,4),length(part21$part_in1[part21$partners=="Loneparents"]),replace=T,prob=probbies[c(2,3,4)])
    part21$part_in2[part21$partners=="Notapplicable"] <- sample(c(1,3,4),length(part21$part_in1[part21$partners=="Notapplicable"]),replace=T,prob=probbies[c(1,3,4)])
    part21$part_in2[part21$partners=="Partners"]      <- sample(c(1,2,4),length(part21$part_in1[part21$partners=="Partners"]),replace=T,prob=probbies[c(1,2,4)])
    part21$part_in2[part21$partners=="Sonsdaughters"] <- sample(c(1,2,3),length(part21$part_in1[part21$partners=="Sonsdaughters"]),replace=T,prob=probbies[c(1,2,3)])
    
    ordata3 <- rbind(part21,part22)
    ordata  <- ordata3
    
    # ME in citizen
    
    ordata$citi_in2 <- ifelse(rbinom(nrow(ordata),1,0.95),ordata$citizen,0)             # partner 2 5% ME
    
    probbies <- unlist(table(ordata$citizen)/sum(table(ordata$citizen)))
    
    part21  <- subset(ordata, ordata[,"citi_in2"]==0)
    part22  <- subset(ordata, ordata[,"citi_in2"]!=0)
    
    part21$citi_in2[part21$citizen=="CitizenEU"]    <- sample(c(2,3,4),length(part21$citi_in1[part21$citizen=="CitizenEU"]),replace=T,prob=probbies[c(2,3,4)])
    part21$citi_in2[part21$citizen=="CitizenNL"]    <- sample(c(1,3,4),length(part21$citi_in1[part21$citizen=="CitizenNL"]),replace=T,prob=probbies[c(1,3,4)])
    part21$citi_in2[part21$citizen=="CitizennotEU"] <- sample(c(1,2,4),length(part21$citi_in1[part21$citizen=="CitizennotEU"]),replace=T,prob=probbies[c(1,2,4)])
    part21$citi_in2[part21$citizen=="Notstated"]    <- sample(c(1,2,3),length(part21$citi_in1[part21$citizen=="Notstated"]),replace=T,prob=probbies[c(1,2,3)])
    
    ordata3 <- rbind(part21,part22)
    ordata  <- ordata3
    
    ordata$misind <- rep(NA, nrow(ordata))
    
    # gebruikt evt MAR missingness mechanisme hier
    
    for(i in 1:length(levels(ordata$age))){
      ordata[ordata$age==levels(ordata$age)[i],"misind"] <- rbinom(nrow(ordata[ordata$age==levels(ordata$age)[i],]),1,probs[i])
    }
    
    ordata[ordata$misind==1,c("citi_in2","gend_in2","part_in2")] <- NA
    
    
    # pak de steekproef
    ordataex <- ordata[!is.na(ordata["gend_in2"]),]
    
    ordataex$extra <- rep(1, nrow(ordataex))
    
    shortiedata <- ddply(ordataex, .(age,marstat,gender,birth,partners,citizen,gend_in1,
                                   gend_in2,part_in1,part_in2,citi_in1,citi_in2), summarise, freq=sum(extra))
    
    bootplace <- matrix(NA, nrow(shortiedata), nboot)
    colnames(bootplace) <- c(paste0("b",rep(1:nboot)))
      
    shortiedata <- cbind(shortiedata, bootplace)
    
    shortiedata[,c(paste0("b",rep(1:nboot)))] <- rmultinom(nboot, sum(shortiedata$freq), shortiedata$freq/sum(shortiedata$freq))
    
    
    write.table(shortiedata, paste0("shortdata.txt"), row.names = F, quote = F)
    
    ordata$extra <- rep(1, nrow(ordata))
    
    longiedata <- ddply(ordata, .(age,marstat,gender,birth,partners,citizen,gend_in1,
                                    gend_in2,part_in1,part_in2,citi_in1,citi_in2), summarise, freq=sum(extra))
    
    write.table(longiedata, paste0("longdata.txt"), row.names = F, quote = F)
    
}