res_imp <- function(imps, nboot, exboot, j){
  
  impimp         <- vector("list", length(exboot))
  impimp_resQb   <- vector("list", length(exboot))
  Between        <- vector("list", length(exboot))
  
  for(i in 1:length(exboot)){
    
    # create empty matrices per exboot
    impimp_resQb[[i]] <- matrix(NA, 32, exboot[i])
    Between[[i]]      <- matrix(NA, 1, 32)
    impimp[[i]]       <- matrix(NA, 1, 64)
    
    # get results per bootstrap (per exboot)
    for(k in 1:exboot[i]){
      impimp_resQb[[i]][,k]  <- as.numeric(as.character(unlist(ddply(imps[[k]], .(i_gen, i_part, i_cit), summarise, freq=sum(as.numeric(as.character(freq))), .drop=FALSE))[97:128]))
    }
    
    # obtain between and final results per exboot per j
    for(k in 1:32){
      impimp[[i]][1,k]    <- mean(impimp_resQb[[i]][k,])
      Between[[i]][,k]    <-  var(log(impimp_resQb[[i]][k,])) 
      impimp[[i]][1,k+32] <- (exboot[i]+1) * (Between[[i]][,k]/exboot[i]) 
    }
    
    write.table(impimp[[i]], paste0("store_res/6_impimp_",exboot[i],"/impimp_",j,".txt"), row.names = F, quote = F)
    
  }
  
}