res_AP <- function(imps, nboot, exboot, j){
  
  impAP         <- vector("list", length(exboot))
  impAP_resQb   <- vector("list", length(exboot))
  Between       <- vector("list", length(exboot))
  
  for(i in 1:length(exboot)){
    
    # create empty matrices per exboot
    impAP_resQb[[i]]  <- matrix(NA, 84, exboot[i])
    Between[[i]]      <- matrix(NA, 1, 84)
    impAP[[i]]       <- matrix(NA, 1, 168)
    
    # get results per bootstrap (per exboot)
    for(k in 1:exboot[i]){
      impAP_resQb[[i]][,k]  <- as.numeric(as.character(unlist(ddply(imps[[k]], .(i_part, age), summarise, freq=sum(as.numeric(as.character(freq))), .drop=FALSE))[169:252]))
    }
    
    # obtain between and final results per exboot per j
    for(k in 1:84){
      impAP[[i]][1,k]    <- mean(impAP_resQb[[i]][k,])
      Between[[i]][,k]   <-  var(log(impAP_resQb[[i]][k,])) 
      impAP[[i]][1,k+84] <- (exboot[i]+1) * (Between[[i]][,k]/exboot[i]) 
    }
    
    write.table(impAP[[i]], paste0("store_res/4_impAP_",exboot[i],"/impAP_",j,".txt"), row.names = F, quote = F)
    
  }
  
}