res_gen <- function(imps, nboot, exboot, j){
  
  impgen       <- vector("list", length(exboot))
  impgen_resQb <- vector("list", length(exboot))
  Between      <- vector("list", length(exboot))
  
  for(i in 1:length(exboot)){
    
    # create empty matrices per exboot
    impgen_resQb[[i]] <- matrix(NA, 2, exboot[i])
    Between[[i]]      <- matrix(NA, 1, 2)
    impgen[[i]]       <- matrix(NA, 1, 4)
    
    # get results per bootstrap (per exboot)
    for(k in 1:exboot[i]){
      impgen_resQb[[i]][,k]  <- as.numeric(as.character(unlist(ddply(imps[[k]], .(i_gen), summarise, freq=sum(as.numeric(as.character(freq)))))[3:4]))
    }
  
    # obtain between and final results per exboot per j
    for(k in 1:2){
      impgen[[i]][1,k]   <- mean(impgen_resQb[[i]][k,])
      Between[[i]][,k]   <-  var(log(impgen_resQb[[i]][k,])) 
      impgen[[i]][1,k+2] <- (exboot[i]+1) * (Between[[i]][,k]/exboot[i]) 
    }
    
    write.table(impgen[[i]], paste0("store_res/1_impgen_",exboot[i],"/impgen_",j,".txt"), row.names = F, quote = F)
        
  }
  
}