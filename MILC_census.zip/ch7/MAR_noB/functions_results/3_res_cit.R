res_cit <- function(imps, nboot, exboot, j){
  
  impcit        <- vector("list", length(exboot))
  impcit_resQb  <- vector("list", length(exboot))
  Between       <- vector("list", length(exboot))
  
  for(i in 1:length(exboot)){
    
    # create empty matrices per exboot
    impcit_resQb[[i]] <- matrix(NA, 4, exboot[i])
    Between[[i]]      <- matrix(NA, 1, 4)
    impcit[[i]]       <- matrix(NA, 1, 8)
    
    # get results per bootstrap (per exboot)
    for(k in 1:exboot[i]){
      impcit_resQb[[i]][,k]  <- as.numeric(as.character(unlist(ddply(imps[[k]], .(i_cit), summarise, freq=sum(as.numeric(as.character(freq)))))[5:8]))
    }
    
    # obtain between and final results per exboot per j
    for(k in 1:4){
      impcit[[i]][1,k]   <- mean(impcit_resQb[[i]][k,])
      Between[[i]][,k]   <-  var(log(impcit_resQb[[i]][k,])) 
      impcit[[i]][1,k+4] <- (exboot[i]+1) * (Between[[i]][,k]/exboot[i]) 
    }
    
    write.table(impcit[[i]], paste0("store_res/3_impcit_",exboot[i],"/impcit_",j,".txt"), row.names = F, quote = F)
    
  }
  
}