res_par <- function(imps, nboot, exboot, j){
  
  imppar        <- vector("list", length(exboot))
  imppar_resQb  <- vector("list", length(exboot))
  Between       <- vector("list", length(exboot))
  
  for(i in 1:length(exboot)){
    
    # create empty matrices per exboot
    imppar_resQb[[i]] <- matrix(NA, 4, exboot[i])
    Between[[i]]      <- matrix(NA, 1, 4)
    imppar[[i]]       <- matrix(NA, 1, 8)
    
    # get results per bootstrap (per exboot)
    for(k in 1:exboot[i]){
      imppar_resQb[[i]][,k]  <- as.numeric(as.character(unlist(ddply(imps[[k]], .(i_part), summarise, freq=sum(as.numeric(as.character(freq)))))[5:8]))
    }
    
    # obtain between and final results per exboot per j
    for(k in 1:4){
      imppar[[i]][1,k]   <- mean(imppar_resQb[[i]][k,])
      Between[[i]][,k]   <-  var(log(imppar_resQb[[i]][k,])) 
      imppar[[i]][1,k+4] <- (exboot[i]+1) * (Between[[i]][,k]/exboot[i]) 
    }
    
    write.table(imppar[[i]], paste0("store_res/2_imppar_",exboot[i],"/imppar_",j,".txt"), row.names = F, quote = F)
    
  }
  
}