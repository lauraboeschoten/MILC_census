res_ALL <- function(imps, nboot, exboot, j){
  
  impALL         <- vector("list", length(exboot))
  impALL_resQb   <- vector("list", length(exboot))
  Between        <- vector("list", length(exboot))
  
  for(i in 1:length(exboot)){
    
    # create empty matrices per exboot
    impALL_resQb[[i]] <- matrix(NA, 14112, exboot[i])
    Between[[i]]      <- matrix(NA, 1, 14112)
    impALL[[i]]       <- matrix(NA, 1, 28224)
    
    # get results per bootstrap (per exboot)
    for(k in 1:exboot[i]){
      impALL_resQb[[i]][,k]  <- as.numeric(as.character(unlist(ddply(imps[[k]], .(i_gen, i_part, i_cit, age, marstat, birth), summarise, freq=sum(as.numeric(as.character(freq))), .drop=FALSE))[84673:98784]))
    }
    
    # obtain between and final results per exboot per j
    for(k in 1:14112){
      impALL[[i]][1,k]    <- mean(impALL_resQb[[i]][k,])
      Between[[i]][,k]    <-  var(log(impALL_resQb[[i]][k,])) 
      impALL[[i]][1,k+14112] <- (exboot[i]+1) * (Between[[i]][,k]/exboot[i]) 
    }
    
    write.table(impALL[[i]], paste0("store_res/5_impALL_",exboot[i],"/impALL_",j,".txt"), row.names = F, quote = F)
    
  }
  
}