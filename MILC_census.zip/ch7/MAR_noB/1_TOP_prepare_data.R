setwd("C:/Users/lboescho/surfdrive/project_census/simulatie/MCAR_noB")
set.seed(123)
require("readxl")



exceldata  <- read_excel("xlsoutput_HC50_2017_07_11_13_59.xlsx", 1)             # load excel with censusdata


varcats <- list(
  age      = c("under5years", "5to9years",   "10to14years", "15to19years",      # create grid with all combinations
               "20to24years", "25to29years", "30to34years", "35to39years",      # of scores on all variables
               "40to44years", "45to49years", "50to54years", "55to59years",
               "60to64years", "65to69years", "70to74years", "75to79years",
               "80to84years", "85to89years", "90to94years", "95to99years",
               "100yearsandover"),
  marstat  = c("Nevermarried", "Married", "Widowed",	"Divorced",	
               "Registeredpartnership", "Widowofregisteredpartner",
               "Divorcedfromregisteredpartner", "Notstated"),
  gender   = c("Male","Female"),
  birth    = c("NL","EU","NotEU","Other","Notstated"),
  partners = c("Partners","Loneparents","Sonsdaughters","Notstated",
               "Notapplicable"),
  citizen  = c("CitizenNL", "CitizenEU", "CitizennotEU", "Stateless",
               "Notstated"))

data <- expand.grid(varcats)


data$frequency <- NULL                                                          # and put the frequencies in there
data$nblock    <- rep(1:250, each=168)
blockdata      <- split(data, data$nblock)

for(i in 1:250){
  blockdata[[i]]$frequency <- as.numeric(as.matrix(exceldata[(13+((i-1)*30)):
                                                               (33+((i-1)*30)),
                                                             c(2,4,6,8,10,12,14,16)]))
}

totaldata <- do.call("rbind", blockdata)
freqdata  <- subset(totaldata, frequency>0)

new.matrix <- NULL                                                              # turn the short format into a long format   
for (j in 1:nrow(freqdata)){                                                    
  cat(j)
  old.matrix <- matrix(rep(as.matrix(lapply(freqdata[j,1:8], as.character)),
                           freqdata[j,8]), freqdata[j,8],8, byrow=T)                                
  new.matrix <- rbind(old.matrix, new.matrix)                                   
}                                                                             

new.result <- matrix(unlist(new.matrix), ncol=ncol(new.matrix),               
                     dimnames=list(NULL, colnames(new.matrix)))

# put it into a data frame
long_data <- as.data.frame(new.result)                                        
colnames(long_data) <- c("age","marstat","gender","birth","partners","citizen",
                         "freq","block")

ordata <- long_data

ordata$gend_in1 <- ifelse(rbinom(nrow(ordata),1,0.95),ordata$gender,                # gender 1 1% ME
                          factor(ordata$gender, levels=rev(levels(ordata$gender))))

ordata$part_in1 <- ifelse(rbinom(nrow(ordata),1,0.95),ordata$partners,0)             # partner 1 1% ME

part11 <- subset(ordata, ordata[,"part_in1"]==0)
part12 <- subset(ordata, ordata[,"part_in1"]!=0)

probbies <- unlist(table(ordata$partners)/sum(table(ordata$partners)))

part11$part_in1[part11$partners=="Loneparents"]   <- sample(c(2,3,4),length(part11$part_in1[part11$partners=="Loneparents"]),replace=T,prob=probbies[c(2,3,4)])
part11$part_in1[part11$partners=="Notapplicable"] <- sample(c(1,3,4),length(part11$part_in1[part11$partners=="Notapplicable"]),replace=T,prob=probbies[c(1,3,4)])
part11$part_in1[part11$partners=="Partners"]      <- sample(c(1,2,4),length(part11$part_in1[part11$partners=="Partners"]),replace=T,prob=probbies[c(1,2,4)])
part11$part_in1[part11$partners=="Sonsdaughters"] <- sample(c(1,2,3),length(part11$part_in1[part11$partners=="Sonsdaughters"]),replace=T,prob=probbies[c(1,2,3)])
ordata <- rbind(part11,part12)

ordata$citi_in1 <- ifelse(rbinom(nrow(ordata),1,0.95),ordata$citizen,0) 

part11 <- subset(ordata, ordata[,"citi_in1"]==0)
part12 <- subset(ordata, ordata[,"citi_in1"]!=0)

probbies <- unlist(table(ordata$citizen)/sum(table(ordata$citizen)))

part11$citi_in1[part11$citizen=="CitizenEU"]    <- sample(c(2,3,4),length(part11$citi_in1[part11$citizen=="CitizenEU"]),replace=T,prob=probbies[c(2,3,4)])
part11$citi_in1[part11$citizen=="CitizenNL"]    <- sample(c(1,3,4),length(part11$citi_in1[part11$citizen=="CitizenNL"]),replace=T,prob=probbies[c(1,3,4)])
part11$citi_in1[part11$citizen=="CitizennotEU"] <- sample(c(1,2,4),length(part11$citi_in1[part11$citizen=="CitizennotEU"]),replace=T,prob=probbies[c(1,2,4)])
part11$citi_in1[part11$citizen=="Notstated"]    <- sample(c(1,2,3),length(part11$citi_in1[part11$citizen=="Notstated"]),replace=T,prob=probbies[c(1,2,3)])

ordata2 <- rbind(part11,part12)


write.table(ordata2, "original_data.txt", quote=FALSE, row.names=FALSE)



