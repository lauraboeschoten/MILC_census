output_ALL_5 <- function(ordata){
  
  pop <- as.numeric(as.character(unlist(ddply(ordata, .(gender, partners, citizen, age, marstat, birth), summarise, freq=sum(as.numeric(as.character(ext))), .drop=FALSE))[84673:98784]))
  
  res <- matrix(NA, nsim, 28224)
  
  for(i in 1:nsim){
    res[i,] <- as.matrix(read.delim(paste0("store_res/5_impALL_5/impALL_",i,".txt"), header=T, sep="")) 
  }
  
  bias <-  matrix(NA, nsim, (length(pop)))
  cov <- matrix(NA, nsim, (length(pop)*3))
  
  for(i in 1:(length(pop))){
    bias[,i]   <- res[,i]-pop[i]
  }
  
  a <- round(colMeans(abs(bias)),4)                                               # absolute bias
  
  
  # hier is de correctie nu uit
  for(i in 1:(length(pop))){
    cov[,i]    <- exp(log(res[,i])-1.96*sqrt(res[,i+(length(pop))]))
    cov[,i+(length(pop))]  <- exp(log(res[,i])+1.96*sqrt(res[,i+(length(pop))]))
    cov[,i+(length(pop)*2)]  <- pop[i] > cov[,i] & pop[i] < cov[,i+(length(pop))]
  }
  
  b <- colSums(cov[,c((length(pop)*2+1):(length(pop)*3))])/nsim*100               # uncorrected coverage
  c <- round(colMeans(cov[,c((length(pop)+1):(length(pop)*2))]-cov[,c(1:(length(pop)))]),4) # CI width
  e <- f <- d <- NULL
  
  for(i in 1:(length(pop))){
    e[i] <- sqrt(mean(res[,i+(length(pop))]))/sd(log(res[,i]))                    # sesd
    f[i] <- sqrt(abs(mean(bias[,i])))                                             # rmse
  }
  
  biastest <- NULL 
  
  for(i in 1:length(pop)){
    biastest[i] <- sd(res[,i])/a[i]                                               # test for systematic bias
  }
  
  # hier is de correctie nu uit
  for(i in 1:(length(pop))){
    cov[,i]    <- exp(log(res[,i]-a[i])-1.96*sqrt(res[,i+(length(pop))]))
    cov[,i+(length(pop))]  <- exp(log(res[,i]+a[i])+1.96*sqrt(res[,i+(length(pop))]))
    cov[,i+(length(pop)*2)]  <- pop[i] > cov[,i] & pop[i] < cov[,i+(length(pop))]
  }
  
  g <- colSums(cov[,c((length(pop)*2+1):(length(pop)*3))])/nsim*100               # corrected coverage
  
  for(i in 1:(length(pop))){d <- c(d,a[i],b[i],c[i],e[i],f[i],biastest[i],g[i])}
  
  d <- matrix(t(as.matrix(d)),byrow=T, ncol=7)
  colnames(d) <- c("bias","cov","ciwidth","sesd","rmse","biastest","corcov")
  zz <- ddply(ordata, .(gender, partners, citizen, age, marstat, birth), summarise, freq=sum(as.numeric(as.character(ext))), .drop=FALSE)
  
  dz <- cbind(zz, d)
  xt <- xtable(dz, digits=4)
  
  plot(table(b))
  plot(table(g))
  plot(dz$freq, dz$a)
  
  return(xt)
}

#-------------------------------------------------------------------------------

output_ALL_10 <- function(ordata){
  
  pop <- as.numeric(as.character(unlist(ddply(ordata, .(gender, partners, citizen, age, marstat, birth), summarise, freq=sum(as.numeric(as.character(ext))), .drop=FALSE))[84673:98784]))
  
  res <- matrix(NA, nsim, 28224)
  
  for(i in 1:nsim){
    res[i,] <- as.matrix(read.delim(paste0("store_res/5_impALL_10/impALL_",i,".txt"), header=T, sep="")) 
  }
  
  bias <-  matrix(NA, nsim, (length(pop)))
  cov <- matrix(NA, nsim, (length(pop)*3))
  
  for(i in 1:(length(pop))){
    bias[,i]   <- res[,i]-pop[i]
  }
  
  a <- round(colMeans(abs(bias)),4)                                               # absolute bias
  
  
  # hier is de correctie nu uit
  for(i in 1:(length(pop))){
    cov[,i]    <- exp(log(res[,i])-1.96*sqrt(res[,i+(length(pop))]))
    cov[,i+(length(pop))]  <- exp(log(res[,i])+1.96*sqrt(res[,i+(length(pop))]))
    cov[,i+(length(pop)*2)]  <- pop[i] > cov[,i] & pop[i] < cov[,i+(length(pop))]
  }
  
  b <- colSums(cov[,c((length(pop)*2+1):(length(pop)*3))])/nsim*100               # uncorrected coverage
  c <- round(colMeans(cov[,c((length(pop)+1):(length(pop)*2))]-cov[,c(1:(length(pop)))]),4) # CI width
  e <- f <- d <- NULL
  
  for(i in 1:(length(pop))){
    e[i] <- sqrt(mean(res[,i+(length(pop))]))/sd(log(res[,i]))                    # sesd
    f[i] <- sqrt(abs(mean(bias[,i])))                                             # rmse
  }
  
  biastest <- NULL 
  
  for(i in 1:length(pop)){
    biastest[i] <- sd(res[,i])/a[i]                                               # test for systematic bias
  }
  
  # hier is de correctie nu uit
  for(i in 1:(length(pop))){
    cov[,i]    <- exp(log(res[,i]-a[i])-1.96*sqrt(res[,i+(length(pop))]))
    cov[,i+(length(pop))]  <- exp(log(res[,i]+a[i])+1.96*sqrt(res[,i+(length(pop))]))
    cov[,i+(length(pop)*2)]  <- pop[i] > cov[,i] & pop[i] < cov[,i+(length(pop))]
  }
  
  g <- colSums(cov[,c((length(pop)*2+1):(length(pop)*3))])/nsim*100               # corrected coverage
  
  for(i in 1:(length(pop))){d <- c(d,a[i],b[i],c[i],e[i],f[i],biastest[i],g[i])}
  
  d <- matrix(t(as.matrix(d)),byrow=T, ncol=7)
  colnames(d) <- c("bias","cov","ciwidth","sesd","rmse","biastest","corcov")
  zz <- ddply(ordata, .(gender, partners, citizen, age, marstat, birth), summarise, freq=sum(as.numeric(as.character(ext))))
  
  dz <- cbind(zz, d)
  xt <- xtable(dz, digits=4)
  
  return(xt)
}

#-------------------------------------------------------------------------------

output_ALL_15 <- function(ordata){
  
  pop <- as.numeric(as.character(unlist(ddply(ordata, .(gender, partners, citizen, age, marstat, birth), summarise, freq=sum(as.numeric(as.character(ext))), .drop=FALSE))[84673:98784]))
  
  res <- matrix(NA, nsim, 28224)
  
  for(i in 1:nsim){
    res[i,] <- as.matrix(read.delim(paste0("store_res/5_impALL_15/impALL_",i,".txt"), header=T, sep="")) 
  }
  
  bias <-  matrix(NA, nsim, (length(pop)))
  cov <- matrix(NA, nsim, (length(pop)*3))
  
  for(i in 1:(length(pop))){
    bias[,i]   <- res[,i]-pop[i]
  }
  
  a <- round(colMeans(abs(bias)),4)                                               # absolute bias
  
  
  # hier is de correctie nu uit
  for(i in 1:(length(pop))){
    cov[,i]    <- exp(log(res[,i])-1.96*sqrt(res[,i+(length(pop))]))
    cov[,i+(length(pop))]  <- exp(log(res[,i])+1.96*sqrt(res[,i+(length(pop))]))
    cov[,i+(length(pop)*2)]  <- pop[i] > cov[,i] & pop[i] < cov[,i+(length(pop))]
  }
  
  b <- colSums(cov[,c((length(pop)*2+1):(length(pop)*3))])/nsim*100               # uncorrected coverage
  c <- round(colMeans(cov[,c((length(pop)+1):(length(pop)*2))]-cov[,c(1:(length(pop)))]),4) # CI width
  e <- f <- d <- NULL
  
  for(i in 1:(length(pop))){
    e[i] <- sqrt(mean(res[,i+(length(pop))]))/sd(log(res[,i]))                    # sesd
    f[i] <- sqrt(abs(mean(bias[,i])))                                             # rmse
  }
  
  biastest <- NULL 
  
  for(i in 1:length(pop)){
    biastest[i] <- sd(res[,i])/a[i]                                               # test for systematic bias
  }
  
  # hier is de correctie nu uit
  for(i in 1:(length(pop))){
    cov[,i]    <- exp(log(res[,i]-a[i])-1.96*sqrt(res[,i+(length(pop))]))
    cov[,i+(length(pop))]  <- exp(log(res[,i]+a[i])+1.96*sqrt(res[,i+(length(pop))]))
    cov[,i+(length(pop)*2)]  <- pop[i] > cov[,i] & pop[i] < cov[,i+(length(pop))]
  }
  
  g <- colSums(cov[,c((length(pop)*2+1):(length(pop)*3))])/nsim*100               # corrected coverage
  
  for(i in 1:(length(pop))){d <- c(d,a[i],b[i],c[i],e[i],f[i],biastest[i],g[i])}
  
  d <- matrix(t(as.matrix(d)),byrow=T, ncol=7)
  colnames(d) <- c("bias","cov","ciwidth","sesd","rmse","biastest","corcov")
  zz <- ddply(ordata, .(gender, partners, citizen, age, marstat, birth), summarise, freq=sum(as.numeric(as.character(ext))))
  
  dz <- cbind(zz, d)
  xt <- xtable(dz, digits=4)
  
  return(xt)
}

#-------------------------------------------------------------------------------

output_ALL_20 <- function(ordata){
  
  pop <- as.numeric(as.character(unlist(ddply(ordata, .(gender, partners, citizen, age, marstat, birth), summarise, freq=sum(as.numeric(as.character(ext))), .drop=FALSE))[84673:98784]))
  
  res <- matrix(NA, nsim, 28224)
  
  for(i in 1:nsim){
    res[i,] <- as.matrix(read.delim(paste0("store_res/5_impALL_20/impALL_",i,".txt"), header=T, sep="")) 
  }
  
  bias <-  matrix(NA, nsim, (length(pop)))
  cov <- matrix(NA, nsim, (length(pop)*3))
  
  for(i in 1:(length(pop))){
    bias[,i]   <- res[,i]-pop[i]
  }
  
  a <- round(colMeans(abs(bias)),4)                                               # absolute bias
  
  
  # hier is de correctie nu uit
  for(i in 1:(length(pop))){
    cov[,i]    <- exp(log(res[,i])-1.96*sqrt(res[,i+(length(pop))]))
    cov[,i+(length(pop))]  <- exp(log(res[,i])+1.96*sqrt(res[,i+(length(pop))]))
    cov[,i+(length(pop)*2)]  <- pop[i] > cov[,i] & pop[i] < cov[,i+(length(pop))]
  }
  
  b <- colSums(cov[,c((length(pop)*2+1):(length(pop)*3))])/nsim*100               # uncorrected coverage
  c <- round(colMeans(cov[,c((length(pop)+1):(length(pop)*2))]-cov[,c(1:(length(pop)))]),4) # CI width
  e <- f <- d <- NULL
  
  for(i in 1:(length(pop))){
    e[i] <- sqrt(mean(res[,i+(length(pop))]))/sd(log(res[,i]))                    # sesd
    f[i] <- sqrt(abs(mean(bias[,i])))                                             # rmse
  }
  
  biastest <- NULL 
  
  for(i in 1:length(pop)){
    biastest[i] <- sd(res[,i])/a[i]                                               # test for systematic bias
  }
  
  # hier is de correctie nu uit
  for(i in 1:(length(pop))){
    cov[,i]    <- exp(log(res[,i]-a[i])-1.96*sqrt(res[,i+(length(pop))]))
    cov[,i+(length(pop))]  <- exp(log(res[,i]+a[i])+1.96*sqrt(res[,i+(length(pop))]))
    cov[,i+(length(pop)*2)]  <- pop[i] > cov[,i] & pop[i] < cov[,i+(length(pop))]
  }
  
  g <- colSums(cov[,c((length(pop)*2+1):(length(pop)*3))])/nsim*100               # corrected coverage
  
  for(i in 1:(length(pop))){d <- c(d,a[i],b[i],c[i],e[i],f[i],biastest[i],g[i])}
  
  d <- matrix(t(as.matrix(d)),byrow=T, ncol=7)
  colnames(d) <- c("bias","cov","ciwidth","sesd","rmse","biastest","corcov")
  zz <- ddply(ordata, .(gender, partners, citizen, age, marstat, birth), summarise, freq=sum(as.numeric(as.character(ext))))
  
  dz <- cbind(zz, d)
  xt <- xtable(dz, digits=4)
  
  return(xt)
}

