setwd("C:/Users/lboescho/surfdrive/project_census/simulatie/MCAR_noB")

options(scipen = 999)

library(xtable)
library(plyr)

#global parameters
nsim   <- 500

ordata <- read.table("original_data.txt", header=TRUE)
ordata$ext <- rep(1, nrow(ordata))

pop <- as.numeric(as.character(unlist(ddply(ordata, .(gender, partners, citizen, 
       age, marstat, birth), summarise, freq=sum(as.numeric(as.character(ext))), 
       .drop=FALSE))[84673:98784]))

# ------------------------------------------------------------------------------
# 1. Y1 results
setwd("C:/Users/lboescho/surfdrive/project_census/simulatie/Y1")
res <- matrix(NA, nsim, 28224)

for(i in 1:nsim){
  cat(i)
  res[i,] <- as.matrix(read.delim(paste0("store_res/5_impALL/impALL_",i,".txt"), 
                                  header=T, sep="")) 
}

bias <- matrix(NA, nsim, (length(pop)))

for(i in 1:(length(pop))){
  bias[,i]   <- res[,i]-pop[i]
}

a <- round(colMeans(bias)) 
f <- NULL

for(i in 1:(length(pop))){
  f[i] <- sqrt(mean(bias[,i]^2))                                            
}

Y1bias <- as.data.frame(cbind(pop, a))
Y1bias$ID <- rep("1. Y1", nrow(Y1bias))

Y1rmse <- as.data.frame(cbind(pop, f))
Y1rmse$ID <- rep("1. Y1", nrow(Y1rmse))

# ------------------------------------------------------------------------------
# 1. MCAR 5 results
setwd("C:/Users/lboescho/surfdrive/project_census/simulatie/MCAR_noB")
res <- matrix(NA, nsim, 28224)

for(i in 1:nsim){
  res[i,] <- as.matrix(read.delim(paste0("store_res/5_impALL_5/impALL_",i,".txt"), 
                                  header=T, sep="")) 
}

bias <- matrix(NA, nsim, (length(pop)))

for(i in 1:(length(pop))){
  bias[,i]   <- res[,i]-pop[i]
}

a <- round(colMeans(abs(bias)),4)                                               
e <- NULL

for(i in 1:(length(pop))){
  e[i] <- sqrt(mean(res[,i+(length(pop))]))/sd(log(res[,i]))                    
}

MCAR5sesd <- as.data.frame(cbind(pop, e))
MCAR5sesd$ID <- rep("1. MCAR 5", nrow(MCAR5sesd))

# ------------------------------------------------------------------------------
# 1. MCAR 10 results
setwd("C:/Users/lboescho/surfdrive/project_census/simulatie/MCAR_noB")
res <- matrix(NA, nsim, 28224)

for(i in 1:nsim){
  res[i,] <- as.matrix(read.delim(paste0("store_res/5_impALL_10/impALL_",i,".txt"), 
                                  header=T, sep="")) 
}

bias <- matrix(NA, nsim, (length(pop)))

for(i in 1:(length(pop))){
  bias[,i]   <- res[,i]-pop[i]
}

a <- round(colMeans(abs(bias)),4)                                               
e <- NULL

for(i in 1:(length(pop))){
  e[i] <- sqrt(mean(res[,i+(length(pop))]))/sd(log(res[,i]))                    
}

MCAR10sesd <- as.data.frame(cbind(pop, e))
MCAR10sesd$ID <- rep("2. MCAR 10", nrow(MCAR10sesd))

# ------------------------------------------------------------------------------
# 1. MCAR 20 results
setwd("C:/Users/lboescho/surfdrive/project_census/simulatie/MCAR_noB")
res <- matrix(NA, nsim, 28224)

for(i in 1:nsim){
  cat(i)
  res[i,] <- as.matrix(read.delim(paste0("store_res/5_impALL_20/impALL_",i,".txt"), 
                                  header=T, sep="")) 
}

bias <- matrix(NA, nsim, (length(pop)))

for(i in 1:(length(pop))){
  bias[,i]   <- res[,i]-pop[i]
}

a <- round(colMeans(bias)) 
f <- e <- NULL

for(i in 1:(length(pop))){
  e[i] <- sqrt(mean(res[,i+(length(pop))]))/sd(log(res[,i]))  
  f[i] <- sqrt(mean(bias[,i]^2))                                            
}

MCAR20bias <- as.data.frame(cbind(pop, a))
MCAR20bias$ID <- rep("2. MCAR 20", nrow(MCAR20bias))

MCAR20sesd <- as.data.frame(cbind(pop, e))
MCAR20sesd$ID <- rep("3. MCAR 20", nrow(MCAR20sesd))

MCAR20rmse <- as.data.frame(cbind(pop, f))
MCAR20rmse$ID <- rep("2. MCAR 20", nrow(MCAR20rmse))

# ------------------------------------------------------------------------------
# 1. MAR 5 results
setwd("C:/Users/lboescho/surfdrive/project_census/simulatie/MAR_noB")
res <- matrix(NA, nsim, 28224)

for(i in 1:nsim){
  res[i,] <- as.matrix(read.delim(paste0("store_res/5_impALL_5/impALL_",i,".txt"), 
                                  header=T, sep="")) 
}

bias <- matrix(NA, nsim, (length(pop)))

for(i in 1:(length(pop))){
  bias[,i]   <- res[,i]-pop[i]
}

a <- round(colMeans(bias)) 
f <- e <- NULL

for(i in 1:(length(pop))){
  e[i] <- sqrt(mean(res[,i+(length(pop))]))/sd(log(res[,i]))  
  f[i] <- sqrt(mean(bias[,i]^2))                                            
}

MAR5sesd <- as.data.frame(cbind(pop, e))
MAR5sesd$ID <- rep("4. MAR 5", nrow(MAR5sesd))

# ------------------------------------------------------------------------------
# 1. MAR 10 results
setwd("C:/Users/lboescho/surfdrive/project_census/simulatie/MAR_noB")
res <- matrix(NA, nsim, 28224)

for(i in 1:nsim){
  res[i,] <- as.matrix(read.delim(paste0("store_res/5_impALL_10/impALL_",i,".txt"), 
                                  header=T, sep="")) 
}

bias <- matrix(NA, nsim, (length(pop)))

for(i in 1:(length(pop))){
  bias[,i]   <- res[,i]-pop[i]
}

a <- round(colMeans(bias)) 
f <- e <- NULL

for(i in 1:(length(pop))){
  e[i] <- sqrt(mean(res[,i+(length(pop))]))/sd(log(res[,i]))  
  f[i] <- sqrt(mean(bias[,i]^2))                                            
}


MAR10sesd <- as.data.frame(cbind(pop, e))
MAR10sesd$ID <- rep("5. MAR 10", nrow(MAR10sesd))

# ------------------------------------------------------------------------------
# 1. MAR 20 results
setwd("C:/Users/lboescho/surfdrive/project_census/simulatie/MAR_noB")
res <- matrix(NA, nsim, 28224)

for(i in 1:nsim){
  cat(i)
  res[i,] <- as.matrix(read.delim(paste0("store_res/5_impALL_20/impALL_",i,".txt"), 
                                  header=T, sep="")) 
}

bias <- matrix(NA, nsim, (length(pop)))

for(i in 1:(length(pop))){
  bias[,i]   <- res[,i]-pop[i]
}

a <- round(colMeans(bias)) 
f <- e <- NULL

for(i in 1:(length(pop))){
  e[i] <- sqrt(mean(res[,i+(length(pop))]))/sd(log(res[,i]))  
  f[i] <- sqrt(mean(bias[,i]^2))                                            
}

MAR20bias <- as.data.frame(cbind(pop, a))
MAR20bias$ID <- rep("3. MAR 20", nrow(MAR20bias))

MAR20sesd <- as.data.frame(cbind(pop, e))
MAR20sesd$ID <- rep("6. MAR 20", nrow(MAR20sesd))

MAR20rmse <- as.data.frame(cbind(pop, f))
MAR20rmse$ID <- rep("6. MAR 20", nrow(MAR20rmse))

# ------------------------------------------------------------------------------
library("ggplot2")

# plot bias
ALLbias <- rbind(Y1bias, MCAR20bias, MAR20bias)

ggplot(ALLbias, aes(x=pop, y=a, color=ID)) +
  geom_point(shape=16) + 
  facet_wrap(~ID) +
  xlab("Cell frequency") +
  ylab("Absolute bias") +
  theme_bw() +
  #scale_y_continuous(breaks=seq(0,8000,750)) + 
  scale_color_manual(values=c("#006666","#FF6600", "#006600")) 

# ------------------------------------------------------------------------------
# plot rmse
ALLbias <- rbind(Y1rmse, MCAR20rmse, MAR20rmse)

ggplot(ALLbias, aes(x=pop, y=f, color=ID)) +
  geom_point(shape=16) + 
  facet_wrap(~ID) +
  xlab("Cell frequency") +
  ylab("RMSE") +
  theme_bw() +
  #scale_y_continuous(breaks=seq(0,100,10)) + 
  scale_color_manual(values=c("#006666","#FF6600", "#006600")) 

# ------------------------------------------------------------------------------
# plot sesd
ALLbias <- rbind(MCAR5sesd, MCAR10sesd, MCAR20sesd, MAR5sesd, MAR10sesd, MAR20sesd)
#ALLbias <- rbind(MCAR5sesd, MCAR10sesd, MCAR20sesd, MAR20sesd)

ggplot(ALLbias, aes(x=pop, y=e, color=ID)) +
  geom_point(shape=16) + 
  facet_wrap(~ID) +
  xlab("Cell frequency") +
  ylab("sesd") +
  theme_bw() +
  geom_hline(yintercept = 1) + 
  scale_color_manual(values=c("#006666","#FF6600", "#006600",
                              "#006666","#FF6600", "#006600")) 

p <- ggplot(ALLbias, aes(x=ID, y=e)) + 
  geom_boxplot()
p
# ------------------------------------------------------------------------------

save.image("dataforplots.RData")
